# SpringBoot2DataRest
Spring Boot Data Rest (Rest Repositories with JPA)
