package com.bpm.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bpm.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer>
{

}
